/*
 * MissedTradeMBean.java
 *
 * Created on April 26, 2007, 11:30 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.sun.oss.trader.mq;

import javax.management.NotificationEmitter;

/**
 *
 * @author jclarke
 */
public interface MissedTradeMBean  extends NotificationEmitter {
    
    
}
