/*
 * TradeManagementMBean.java
 *
 * Created on October 13, 2006, 8:57 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.sun.oss.trader.mq;

import javax.management.NotificationEmitter;

/**
 *
 * @author jclarke
 */
public interface TradeManagementMBean extends NotificationEmitter {
    
}
