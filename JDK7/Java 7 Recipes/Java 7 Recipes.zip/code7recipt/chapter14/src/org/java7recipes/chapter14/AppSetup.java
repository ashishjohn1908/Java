package org.java7recipes.chapter14;

import javax.swing.JFrame;

/**
 *
 * @author cdea
 */
public interface AppSetup {
    void apply(JFrame frame);
}
