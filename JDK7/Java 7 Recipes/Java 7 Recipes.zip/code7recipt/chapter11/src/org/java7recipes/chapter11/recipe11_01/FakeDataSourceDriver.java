
package org.java7recipes.chapter11.recipe11_01;

/**
 * This class represents a fake database driver class that is used for
 * demonstration purposes only.
 * 
 * @author juneau
 */
public class FakeDataSourceDriver {
    
    private String databaseName;
    private String serverName;
    private String description;
    
    public FakeDataSourceDriver(){
        
    }

    /**
     * @return the databaseName
     */
    public String getDatabaseName() {
        return databaseName;
    }

    /**
     * @param databaseName the databaseName to set
     */
    public void setDatabaseName(String databaseName) {
        this.databaseName = databaseName;
    }

    /**
     * @return the serverName
     */
    public String getServerName() {
        return serverName;
    }

    /**
     * @param serverName the serverName to set
     */
    public void setServerName(String serverName) {
        this.serverName = serverName;
    }

    /**
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * @param description the description to set
     */
    public void setDescription(String description) {
        this.description = description;
    }
}
