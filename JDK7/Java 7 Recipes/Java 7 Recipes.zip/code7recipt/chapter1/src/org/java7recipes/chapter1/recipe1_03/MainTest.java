
package org.java7recipes.chapter1.recipe1_03;

/**
 * Recipe 1-3
 * @author juneau
 */
public class MainTest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("Hello World");
    }
}
