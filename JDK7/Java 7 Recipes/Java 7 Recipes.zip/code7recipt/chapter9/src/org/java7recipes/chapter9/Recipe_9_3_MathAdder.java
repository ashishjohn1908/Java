package org.java7recipes.chapter9;

import java.util.Random;

/**
 * Created by IntelliJ IDEA.
 * User: Freddy
 * Date: 9/16/11
 * Time: 5:33 PM
 * Math Adder Class
 */
public class Recipe_9_3_MathAdder {

    public int addNumbers (int first, int second) {
        return first+second;

    }

    public int substractNumber (int first, int second) {
        return first-second;
    }

}
