
package org.java7recipes.chapter7.recipe7_12;


/**
 * Recipe 7-12
 * 
 * 
 * @author juneau
 */
public interface TeamType {
    
    void setName(String name);
    void setCity(String city);
    String getFullName();

}
