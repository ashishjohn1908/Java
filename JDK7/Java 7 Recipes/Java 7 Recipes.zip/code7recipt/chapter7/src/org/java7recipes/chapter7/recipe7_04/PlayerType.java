/*
 * To change this template, choose Tools | Templates and open the template in
 * the editor.
 */
package org.java7recipes.chapter7.recipe7_04;

/**
 *
 * @author juneau
 */
public interface PlayerType {
    public String position = null;
    
    public String getPosition();
}
