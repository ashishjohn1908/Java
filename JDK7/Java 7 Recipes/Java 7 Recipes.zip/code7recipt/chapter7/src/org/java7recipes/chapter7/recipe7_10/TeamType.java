
package org.java7recipes.chapter7.recipe7_10;

/**
 * Recipe 7-10
 * 
 * 
 * @author juneau
 */
public interface TeamType {
    
    void setName(String name);
    void setCity(String city);
    String getFullName();

}
