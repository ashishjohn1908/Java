import java.awt.*;
import java.io.*;

/**
 * Created by IntelliJ IDEA.
 * User: Freddy
 * Date: 8/17/11
 * Time: 10:47 PM
 * Externalizable Example
 */
public class Ch_5_2_ExternalizableExample {
    public static void main(String[] args) {
        Ch_5_2_ExternalizableExample example = new Ch_5_2_ExternalizableExample();
        example.start();
    }

    private void start() {
        ExternalizableProgramSettings settings = new ExternalizableProgramSettings(new Point(10,10),new Dimension(300,200), Color.blue, "The title of the application" );
        saveSettings(settings,"settingsExternalizable.bin");
        ExternalizableProgramSettings loadedSettings = loadSettings("settingsExternalizable.bin");
        System.out.println("Are settings are equal? :"+loadedSettings.equals(settings));


    }

    private void saveSettings(ExternalizableProgramSettings settings, String filename) {
        try {
            FileOutputStream fos = new FileOutputStream(filename);
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(settings);
            oos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private ExternalizableProgramSettings loadSettings(String filename) {
        try {
            FileInputStream fis = new FileInputStream(filename);
            ObjectInputStream ois = new ObjectInputStream(fis);
            return (ExternalizableProgramSettings) ois.readObject();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return null;

    }


}
