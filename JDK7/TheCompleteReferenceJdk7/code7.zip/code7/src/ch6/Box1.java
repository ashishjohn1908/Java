package ch6;
/* A program that uses the Box class.

   Call this file BoxDemo.java
*/
class Box1 {
  double width;
  double height;
  double depth;
}