package ch6;
// This program declares two Box objects.

class Box2 {
  double width;
  double height;
  double depth;
}