package ch6;
class Box11 {
  double width;
  double height;
  double depth;
}